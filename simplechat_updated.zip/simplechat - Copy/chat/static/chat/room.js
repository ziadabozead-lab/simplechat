const chatBox = document.getElementById('chat-box');
const form = document.getElementById('send-form');
const input = document.getElementById('text-input');
const themeToggle = document.getElementById('theme-toggle');
let lastId = LAST_ID;

// ---- Theme toggle ----
// (The <html> element may already carry data-theme="dark" from the
// inline anti-flash script in the template; this just keeps the
// button in sync and handles clicks.)
const themeIcon = themeToggle.querySelector('.icon');
const themeLabel = themeToggle.querySelector('.label');

function setToggleUI(isDark) {
    themeIcon.textContent = isDark ? '☀️' : '🌙';
    themeLabel.textContent = isDark ? 'Light' : 'Dark';
}

setToggleUI(document.documentElement.getAttribute('data-theme') === 'dark');

themeToggle.addEventListener('click', () => {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    if (isDark) {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('chat-theme', 'light');
        setToggleUI(false);
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('chat-theme', 'dark');
        setToggleUI(true);
    }
});

// ---- Nametag colors ----
// Deterministic color per username, so each person keeps the same tag color.
function nameColor(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 65%, 38%)`;
}

// Color the sender tags already rendered by Django.
document.querySelectorAll('.msg.them .sender').forEach(el => {
    el.style.color = nameColor(el.textContent);
});

// ---- Chat scroll + rendering ----
function scrollToBottom() {
    chatBox.scrollTop = chatBox.scrollHeight;
}
scrollToBottom();

function appendMessage(m) {
    const div = document.createElement('div');
    div.className = 'msg ' + (m.is_me ? 'me' : 'them');
    div.dataset.id = m.id;
    let html = '';
    if (!m.is_me) html += '<div class="sender"></div>';
    if (m.type === 'audio') {
        html += '<audio class="voice-note" controls preload="metadata"></audio>';
    } else {
        html += '<div class="text"></div>';
    }
    html += '<div class="time"></div>';
    div.innerHTML = html;
    if (!m.is_me) {
        const senderEl = div.querySelector('.sender');
        senderEl.textContent = m.sender;
        senderEl.style.color = nameColor(m.sender);
    }
    if (m.type === 'audio') {
        div.querySelector('.voice-note').src = m.audio_url;
    } else {
        div.querySelector('.text').textContent = m.text;
    }
    div.querySelector('.time').textContent = m.time;
    chatBox.appendChild(div);
}

// ---- Polling ----
async function poll() {
    const res = await fetch(`/messages/?after=${lastId}`);
    if (res.redirected || res.url.includes('/login/')) {
        window.location.href = LOGIN_URL;
        return;
    }
    const data = await res.json();
    if (data.messages && data.messages.length) {
        data.messages.forEach(m => { appendMessage(m); lastId = m.id; });
        scrollToBottom();
    }
}

setInterval(poll, 2000);

// ---- Sending ----
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    const csrf = form.querySelector('[name=csrfmiddlewaretoken]').value;
    const res = await fetch('/send/', {
        method: 'POST',
        headers: {'X-CSRFToken': csrf, 'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'text=' + encodeURIComponent(text),
    });
    if (res.redirected || res.url.includes('/login/')) {
        window.location.href = LOGIN_URL;
        return;
    }
    poll();
});

// ---- Voice messages ----
const micBtn = document.getElementById('mic-btn');
const recordingBanner = document.getElementById('recording-banner');
const recordingTimeEl = document.getElementById('recording-time');
const recCancelBtn = document.getElementById('rec-cancel');
const recStopBtn = document.getElementById('rec-stop');

let mediaRecorder = null;
let recordedChunks = [];
let recordingTimerId = null;
let recordingSeconds = 0;
let recordingCancelled = false;

// Pick a mime type the current browser's MediaRecorder actually supports.
function pickMimeType() {
    const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    for (const type of candidates) {
        if (window.MediaRecorder && MediaRecorder.isTypeSupported(type)) return type;
    }
    return '';
}

function formatTime(totalSeconds) {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
}

function startTimer() {
    recordingSeconds = 0;
    recordingTimeEl.textContent = formatTime(0);
    recordingTimerId = setInterval(() => {
        recordingSeconds += 1;
        recordingTimeEl.textContent = formatTime(recordingSeconds);
        // Safety cap: auto-stop at 2 minutes so nobody accidentally
        // records (and uploads) something huge.
        if (recordingSeconds >= 120) {
            stopRecording(false);
        }
    }, 1000);
}

function stopTimer() {
    clearInterval(recordingTimerId);
    recordingTimerId = null;
}

async function startRecording() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Voice messages need microphone access, which this browser does not support.');
        return;
    }
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mimeType = pickMimeType();
        mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
        recordedChunks = [];
        recordingCancelled = false;

        mediaRecorder.addEventListener('dataavailable', (e) => {
            if (e.data && e.data.size > 0) recordedChunks.push(e.data);
        });

        mediaRecorder.addEventListener('stop', () => {
            stream.getTracks().forEach((track) => track.stop());
            if (!recordingCancelled && recordedChunks.length) {
                uploadVoiceMessage(new Blob(recordedChunks, { type: mediaRecorder.mimeType || mimeType || 'audio/webm' }));
            }
            recordedChunks = [];
        });

        mediaRecorder.start();
        recordingBanner.classList.remove('hidden');
        micBtn.classList.add('recording');
        startTimer();
    } catch (err) {
        alert('Microphone permission was denied, so a voice message could not be recorded.');
    }
}

function stopRecording(cancelled) {
    recordingCancelled = cancelled;
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
    }
    stopTimer();
    recordingBanner.classList.add('hidden');
    micBtn.classList.remove('recording');
}

async function uploadVoiceMessage(blob) {
    const csrf = form.querySelector('[name=csrfmiddlewaretoken]').value;
    const formData = new FormData();
    const ext = (blob.type.split('/')[1] || 'webm').split(';')[0];
    formData.append('audio', blob, `voice-message.${ext}`);

    const res = await fetch(SEND_VOICE_URL, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrf },
        body: formData,
    });

    if (res.redirected || res.url.includes('/login/')) {
        window.location.href = LOGIN_URL;
        return;
    }

    const data = await res.json();
    if (data.ok && data.message) {
        appendMessage(data.message);
        lastId = Math.max(lastId, data.message.id);
        scrollToBottom();
    } else if (!data.ok) {
        alert(data.error || 'The voice message could not be sent.');
    }
}

micBtn.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        stopRecording(false);
    } else {
        startRecording();
    }
});

recStopBtn.addEventListener('click', () => stopRecording(false));
recCancelBtn.addEventListener('click', () => stopRecording(true));